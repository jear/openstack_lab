<?php
define('_DB_SERVER_', 'prestashopstack-db.service.consul');
define('_DB_NAME_', 'prestashop');
define('_DB_USER_', 'prestashop');
define('_DB_PASSWD_', 'prestashop1234');
define('_DB_PREFIX_', 'ps_');
define('_MYSQL_ENGINE_', 'InnoDB');
define('_PS_CACHING_SYSTEM_', 'CacheMemcache');
define('_PS_CACHE_ENABLED_', '0');
define('_COOKIE_KEY_', '9CA7HkkmwZwSVmn8i8WvPuOGZ92Ewt4pT46SxuEfkVG2Ar9npIM6VL7Y');
define('_COOKIE_IV_', 'xXpGNAQT');
define('_PS_CREATION_DATE_', '2016-07-25');
if (!defined('_PS_VERSION_'))
	define('_PS_VERSION_', '1.6.0.14');
define('_RIJNDAEL_KEY_', 'mMBc8IToFOyAWZsbxMay8SBqxNoj4diu');
define('_RIJNDAEL_IV_', 'RZk38JlBLkYiwgCNZ5aDxA==');
